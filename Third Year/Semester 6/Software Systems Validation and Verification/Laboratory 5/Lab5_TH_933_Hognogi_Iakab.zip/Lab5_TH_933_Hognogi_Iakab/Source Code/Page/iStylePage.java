package org.example.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

import java.util.List;
import java.util.stream.Collectors;


@DefaultUrl("https://istyle.ro")
public class iStylePage extends PageObject {
    @FindBy(id = "algolia-showsearch")
    private WebElementFacade searchButton;

    @FindBy(id = "search")
    private WebElementFacade searchInput;

    @FindBy(className = "algolia-glass")
    private WebElementFacade searchSubmitButton;

    @FindBy(id = "CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll")
    private WebElementFacade cookieButton;

    @FindBy(className = "header-account")
    private WebElementFacade signInButton;

    @FindBy(id = "email")
    private WebElementFacade emailInput;

    @FindBy(id = "pass")
    private WebElementFacade passwordInput;

    @FindBy(id = "send2")
    private WebElementFacade signInRealButton;

    public void open_search() {
        searchButton.click();
    }

    public void enter_keywords(String keyword) {
        searchInput.type(keyword);
    }

    public void lookup_data() {
        WebElementFacade searchSubmitButton = find(By.id("algolia-searchbox"));
        searchSubmitButton.findElement(By.id("algolia-glass")).click();
    }

    public List<String> getProductList() {
        WebElementFacade productList = find(By.className("product_container"));
        return productList.findElements(By.className("row"))
                .stream().map(row -> row.findElement(By.className("col-md-6"))
                        .findElement(By.className("iphone_15_pro_max"))
                        .findElement(By.className("flex"))
                        .findElement(By.tagName("h3")).getText()).collect(Collectors.toList());
    }

    public String getNoResults() {
        return find(By.className("ais-hits__empty")).getText();
    }

    public void accept_cookies() {
        cookieButton.click();
    }

    public void main_sign_in() {
        signInButton.click();
    }

    public void my_account() {
        find(By.id("ui-id-2")).findElement(By.tagName("ul"))
                .findElement(By.className("authorization-link"))
                .findElement(By.tagName("a")).click();
    }

    public void enter_email(String email) {
        emailInput.type(email);
    }

    public void enter_password(String password) {
        passwordInput.type(password);
    }

    public void sign_in_with_credentials() {
        signInRealButton.click();
    }

    public String getCurrentUserLoggedIn() {
        WebElementFacade div = find(By.className("header-account"));
        return div.findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
    }

    public String getAlertPrompt() {
        return find(By.className("message-error"))
                .findElement(By.tagName("div"))
                .getText();
    }
}