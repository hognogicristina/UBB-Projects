package org.example.steps.serenity;

import net.thucydides.core.annotations.Step;
import org.example.pages.iStylePage;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class EndUserSteps {
    iStylePage istylePage;

    @Step
    public void open_search() {
        istylePage.open_search();
    }

    @Step
    public void enters(String keyword) {
        istylePage.enter_keywords(keyword);
    }

    @Step
    public void starts_search() {
        istylePage.lookup_data();
    }

    @Step
    public void goes_to_the_home_page() {
        istylePage.open();
    }

    @Step
    public void accepts_cookies() {
        istylePage.accept_cookies();
    }

    @Step
    public void signs_in() {
        istylePage.main_sign_in();
    }

    @Step
    public void my_account() {
        istylePage.my_account();
    }

    @Step
    public void types_email(String email) {
        istylePage.enter_email(email);
    }

    @Step
    public void types_password(String password) {
        istylePage.enter_password(password);
    }

    @Step
    public void submits_sign_in_with_credentials() {
        istylePage.sign_in_with_credentials();
    }

    @Step
    public void should_see_the_username(String username) {
        assertThat(istylePage.getCurrentUserLoggedIn(), equalTo(username));
    }

    @Step
    public void looks_for(String term) {
        enters(term);
        starts_search();
    }

    @Step
    public void should_see_invalid_search_information(String data) {
        assertThat(istylePage.getNoResults(), equalTo(data));
    }

    @Step
    public void should_see_incorrect_prompt(String data) {
        assertThat(istylePage.getAlertPrompt(), equalTo(data));
    }

    @Step
    public void should_see_search_information(String data) {
        assertThat(istylePage.getProductList(), hasItem(containsString(data)));
    }
}